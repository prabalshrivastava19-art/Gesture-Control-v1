# Gesture Control v1.0 — Android source project

Brand: 🌸⃝⃪꯭⃮⃕⃔𝐏𝐑𝐀𝐁𝐀𝐋⎯꯭̽❤️‍🔥
Subtitle: 🌸⃝⃪꯭⃮⃕⃔𝐆𝐞𝐬𝐭𝐮𝐫𝐞 𝐜𝐨𝐧𝐭𝐫𝐨𝐥 𝐯 𝟏.𝟎⎯꯭̽❤️‍🔥

## What is included
- CameraX front-camera preview and frame analysis.
- MediaPipe Hand Landmarker initialization; model downloads to app cache on first start.
- One raised index finger -> swipe up (next item).
- Two raised fingers -> swipe down (previous item).
- Fist pauses gesture-triggered swipes; open palm resumes them.
- Android AccessibilityService that dispatches swipe gestures.
- Black/purple UI and ON/OFF button.
- GitHub Actions workflow to build a debug APK in the cloud.

## Important limitations
This is a complete first implementation source, but it has **not been compiled or device-tested in this environment**. You may need small compatibility fixes depending on Android/CameraX/MediaPipe versions and your phone.
- Fist/open-palm pause/resume is applied to gesture-triggered swipes. Swipes are one action per recognized gesture, not continuous auto-scrolling.
- The camera runs while the app screen is open; it does not run in the background.
- Persistent notification controls are not implemented in this version.
- First launch needs internet to download the official MediaPipe model. After it is cached, hand tracking can run locally.
- Enable the app's Accessibility service in Android Settings to allow swipes in other apps.
- This does not automate likes, comments, follows, or account actions.

## Build APK using GitHub Actions (phone-friendly)
1. Create a GitHub repository and upload all files/folders from this project ZIP (not the ZIP file itself).
2. Keep the repository branch named `main`.
3. Open the repository's **Actions** tab and allow workflows if prompted.
4. Choose **Build Android APK** then **Run workflow**, or push a commit to `main`.
5. Open the completed workflow run, scroll to **Artifacts**, and download `Gesture-Control-v1.0-debug-apk`.
6. Extract the artifact ZIP to get `app-debug.apk`.

If the build fails, open the run and copy the first red error section. Do not change phone security settings or grant unrelated overlay permissions.
