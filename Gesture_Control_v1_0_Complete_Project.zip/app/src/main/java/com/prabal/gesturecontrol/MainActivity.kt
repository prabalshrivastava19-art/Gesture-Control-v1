package com.prabal.gesturecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var accessibilityButton: Button
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    private var landmarker: HandLandmarker? = null
    private var lastGesture = ""
    private var stableFrames = 0
    private var lastActionAt = 0L
    @Volatile private var scrollingPaused = false
    private var cameraProvider: ProcessCameraProvider? = null

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startDetection() else setStatus("Camera permission is required")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(0xFF08070D.toInt())
        }
        val brand = TextView(this).apply {
            text = "🌸⃝⃪꯭⃮⃕⃔𝐏𝐑𝐀𝐁𝐀𝐋⎯꯭̽❤️‍🔥"
            textSize = 25f; setTextColor(0xFFE9D5FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "🌸⃝⃪꯭⃮⃕⃔𝐆𝐞𝐬𝐭𝐮𝐫𝐞 𝐜𝐨𝐧𝐭𝐫𝐨𝐥 𝐯 𝟏.𝟎⎯꯭̽❤️‍🔥"
            textSize = 16f; setTextColor(0xFFC084FC.toInt()); setPadding(0, dp(8), 0, dp(14))
        }
        status = TextView(this).apply {
            text = "OFF • Camera is stopped"
            textSize = 14f; setTextColor(0xFFD8B4FE.toInt()); setPadding(0, 0, 0, dp(10))
        }
        preview = PreviewView(this).apply {
            setBackgroundColor(0xFF171020.toInt())
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        toggle = Button(this).apply {
            text = "●  TURN ON"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF7C3AED.toInt()))
            setOnClickListener { if (running.get()) stopDetection() else requestStart() }
        }
        accessibilityButton = Button(this).apply {
            text = "ENABLE ACCESSIBILITY"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val mapping = TextView(this).apply {
            text = "☝️  1 finger  — NEXT\\n✌️  2 fingers — PREVIOUS\\n✊  Fist — PAUSE gestures\\n🖐️  Open palm — RESUME\\n\\nKeep the camera preview open while controlling Reels/Shorts. Enable Gesture Control in Accessibility settings."
            textSize = 15f; setTextColor(0xFFEDE9FE.toInt()); setPadding(0, dp(12), 0, dp(4))
        }
        page.addView(brand)
        page.addView(subtitle)
        page.addView(status)
        page.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f).apply { height = 0; bottomMargin = dp(12) })
        page.addView(toggle, LinearLayout.LayoutParams(-1, dp(54)))
        page.addView(accessibilityButton, LinearLayout.LayoutParams(-1, dp(48)))
        page.addView(mapping)
        setContentView(page)
    }

    private fun requestStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startDetection()
        } else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startDetection() {
        if (!running.compareAndSet(false, true)) return
        toggle.text = "■  TURN OFF"
        setStatus("Loading hand-tracking model…")
        cameraExecutor.execute {
            try {
                val model = File(cacheDir, "hand_landmarker.task")
                if (!model.exists() || model.length() < 100_000) {
                    val url = URL("https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 20000; readTimeout = 30000
                    }
                    conn.inputStream.use { input -> model.outputStream().use { output -> input.copyTo(output) } }
                    conn.disconnect()
                }
                val options = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath(model.absolutePath).build())
                    .setRunningMode(RunningMode.LIVE_STREAM)
                    .setNumHands(1)
                    .setMinHandDetectionConfidence(0.55f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .setResultListener { result, _ -> onLandmarks(result) }
                    .setErrorListener { error -> runOnUiThread { setStatus("Hand tracker error: ${error.message}") } }
                    .build()
                landmarker = HandLandmarker.createFromOptions(this, options)
                runOnUiThread {
                    if (running.get()) {
                        setStatus("ON • Show your hand to the front camera")
                        bindCamera()
                    }
                }
            } catch (e: Exception) {
                running.set(false)
                runOnUiThread {
                    toggle.text = "●  TURN ON"
                    setStatus("Could not load model. Check internet, then try again.")
                    Toast.makeText(this, e.message ?: "Model setup failed", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            if (!running.get()) return@addListener
            try {
                val provider = future.get()
                cameraProvider = provider
                val previewUseCase = androidx.camera.core.Preview.Builder().build().also {
                    it.setSurfaceProvider(preview.surfaceProvider)
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { image ->
                    try {
                        if (running.get()) analyzeFrame(image)
                    } catch (_: Exception) {
                    } finally { image.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, previewUseCase, analysis)
            } catch (e: Exception) {
                setStatus("Front camera unavailable")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(proxy: ImageProxy) {
        val source = proxy.toBitmap()
        val rotation = proxy.imageInfo.rotationDegrees
        val rotated = if (rotation == 0) source else Bitmap.createBitmap(
            source, 0, 0, source.width, source.height,
            Matrix().apply { postRotate(rotation.toFloat()) }, true
        )
        val mpImage = BitmapImageBuilder(rotated).build()
        landmarker?.detectAsync(mpImage, System.currentTimeMillis())
        if (rotated !== source) rotated.recycle()
        source.recycle()
    }

    @Synchronized
    private fun onLandmarks(result: HandLandmarkerResult) {
        if (!running.get() || result.landmarks().isEmpty()) {
            lastGesture = ""; stableFrames = 0; return
        }
        val p = result.landmarks()[0]
        fun up(tip: Int, pip: Int) = p[tip].y() < p[pip].y() - 0.025f
        val index = up(8, 6)
        val middle = up(12, 10)
        val ring = up(16, 14)
        val pinky = up(20, 18)
        val count = listOf(index, middle, ring, pinky).count { it }
        val gesture = when {
            index && middle && ring && pinky -> "OPEN"
            index && !middle && !ring && !pinky -> "NEXT"
            index && middle && !ring && !pinky -> "PREVIOUS"
            count == 0 -> "FIST"
            else -> "OTHER"
        }
        if (gesture == lastGesture) stableFrames++ else { lastGesture = gesture; stableFrames = 1 }
        if (stableFrames < 5) return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 1400) return
        when (gesture) {
            "NEXT" -> if (!scrollingPaused) {
                GestureAccessibilityService.next(); lastActionAt = now; showGesture("NEXT • swipe up")
            }
            "PREVIOUS" -> if (!scrollingPaused) {
                GestureAccessibilityService.previous(); lastActionAt = now; showGesture("PREVIOUS • swipe down")
            }
            "FIST" -> {
                scrollingPaused = true
                lastActionAt = now
                showGesture("PAUSED • show open palm to resume")
            }
            "OPEN" -> {
                scrollingPaused = false
                lastActionAt = now
                showGesture("RESUMED • show one or two fingers")
            }
        }
    }

    private fun showGesture(message: String) = runOnUiThread { if (running.get()) setStatus("ON • $message") }
    private fun setStatus(message: String) { if (::status.isInitialized) status.text = message }

    private fun stopDetection() {
        running.set(false)
        cameraProvider?.unbindAll()
        cameraProvider = null
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        toggle.text = "●  TURN ON"
        setStatus("OFF • Camera is stopped")
        lastGesture = ""; stableFrames = 0
        scrollingPaused = false
    }

    override fun onDestroy() {
        stopDetection()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
