package com.prabal.gesturecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent

class GestureAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun swipeNext() = swipe(upward = true)
    fun swipePrevious() = swipe(upward = false)

    private fun swipe(upward: Boolean) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val x = w * 0.5f
        val startY = if (upward) h * 0.78f else h * 0.28f
        val endY = if (upward) h * 0.25f else h * 0.80f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 260)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
            private set

        fun next() { instance?.swipeNext() }
        fun previous() { instance?.swipePrevious() }
    }
}
